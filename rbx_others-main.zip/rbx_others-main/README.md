loadstring(game:HttpGet("https://raw.githubusercontent.com/dizzyhvh/rbx_others/main/scripts/slap_royale.lua"))()
